package com.example.ui.overlay

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DoNotDisturb
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PreferencesManager
import com.example.service.FloatingWindowController
import com.example.service.ToolTab
import com.example.util.InstalledAppsManager
import com.example.util.TimerStopwatchEngine

@Composable
fun OverlayGamingTab(
    onSwitchTab: (ToolTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager.getInstance(context) }
    val windowOpacity by prefs.windowOpacity.collectAsState()

    val isGamingActive by TimerStopwatchEngine.isGamingActive.collectAsState()
    val gamingDurationMs by TimerStopwatchEngine.gamingDurationMs.collectAsState()

    val isFreeFireInstalled = remember { InstalledAppsManager.isFreeFireInstalled(context) }
    val freeFirePkg = remember { InstalledAppsManager.getFreeFirePackage(context) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
            .verticalScroll(rememberScrollState())
            .testTag("overlay_gaming_tab")
    ) {
        // Game Session Live Clock Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (isGamingActive) Color(0xFF10B981) else Color(0xFF334155),
                    RoundedCornerShape(12.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isGamingActive) Color(0xFF10B981) else Color(0xFF64748B))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isGamingActive) "GAME SESSION ACTIVE" else "GAME SESSION TIMER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isGamingActive) Color(0xFF10B981) else Color.LightGray
                        )
                    }
                    Text(
                        text = TimerStopwatchEngine.formatStopwatch(gamingDurationMs),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (!isGamingActive) {
                        Button(
                            onClick = { TimerStopwatchEngine.startGamingSession() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.weight(1f).height(34.dp).testTag("start_game_session_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Session", fontSize = 11.sp)
                        }
                    } else {
                        Button(
                            onClick = { TimerStopwatchEngine.stopGamingSession() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            modifier = Modifier.weight(1f).height(34.dp).testTag("stop_game_session_btn")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pause Session", fontSize = 11.sp)
                        }
                    }
                    OutlinedButton(
                        onClick = { TimerStopwatchEngine.resetGamingSession() },
                        modifier = Modifier.height(34.dp).testTag("reset_game_session_btn")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Free Fire Dedicated Section (If Installed)
        if (isFreeFireInstalled && freeFirePkg != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(12.dp))
                    .clickable {
                        val success = InstalledAppsManager.launchApp(context, freeFirePkg)
                        if (success) {
                            TimerStopwatchEngine.startGamingSession()
                            Toast.makeText(context, "Launching Free Fire...", Toast.LENGTH_SHORT).show()
                        }
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF59E0B)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Gamepad, contentDescription = "Free Fire", tint = Color.Black)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Free Fire Quick Launch", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Text("Starts session timer on launch", fontSize = 10.sp, color = Color.LightGray)
                    }
                    Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Quick In-Game Companion Tools
        Text("IN-GAME UTILITIES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(start = 2.dp, bottom = 4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            GameToolChip(
                icon = Icons.Default.Calculate,
                label = "Calculator",
                color = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f),
                onClick = { onSwitchTab(ToolTab.CALCULATOR) }
            )
            GameToolChip(
                icon = Icons.Default.EditNote,
                label = "Notes",
                color = Color(0xFFA78BFA),
                modifier = Modifier.weight(1f),
                onClick = { onSwitchTab(ToolTab.NOTES) }
            )
            GameToolChip(
                icon = Icons.Default.Timer,
                label = "Timer",
                color = Color(0xFFF472B6),
                modifier = Modifier.weight(1f),
                onClick = { onSwitchTab(ToolTab.TIMER) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Do Not Disturb & System Shortcuts
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                Text("QUICK SYSTEM SETTINGS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            try {
                                val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            }
                        }
                        .background(Color(0xFF334155))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.DoNotDisturb, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Do Not Disturb Settings", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        Text("Silence game interruptions", fontSize = 10.sp, color = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Transparency quick presets
                Text("OVERLAY TRANSPARENCY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.LightGray)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0.50f to "50%", 0.75f to "75%", 0.95f to "Solid").forEach { (op, label) ->
                        val isSelected = (windowOpacity - op) in -0.05f..0.05f
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF334155))
                                .clickable { prefs.setWindowOpacity(op) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameToolChip(
    icon: ImageVector,
    label: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1E293B))
            .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Medium)
    }
}
