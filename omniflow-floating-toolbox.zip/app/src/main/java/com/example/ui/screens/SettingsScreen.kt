package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PreferencesManager

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager.getInstance(context) }

    val bubbleSize by prefs.bubbleSize.collectAsState()
    val windowOpacity by prefs.windowOpacity.collectAsState()
    val hapticsEnabled by prefs.hapticsEnabled.collectAsState()
    val soundEnabled by prefs.soundEnabled.collectAsState()
    val compactLayout by prefs.compactLayout.collectAsState()
    val appTheme by prefs.appTheme.collectAsState()

    var showResetConfirm by remember { mutableStateOf(false) }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset All Settings?") },
            text = { Text("This will revert bubble size, opacity, and preferences to their factory defaults.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        prefs.resetDefaults()
                        showResetConfirm = false
                        Toast.makeText(context, "Settings reset to defaults", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Text("Reset", color = Color(0xFFEF4444))
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("settings_screen")
    ) {
        Text("Settings & Customization", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Configure appearance, overlay sizing, and permissions", fontSize = 11.sp, color = Color.LightGray)

        Spacer(modifier = Modifier.height(16.dp))

        // FLOATING WINDOW APPEARANCE
        Text("OVERLAY APPEARANCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                // Floating Bubble Size
                Text("Floating Bubble Size", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Controls the draggable floating icon diameter (${bubbleSize}dp)", fontSize = 11.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(44 to "Small (44dp)", 56 to "Medium (56dp)", 68 to "Large (68dp)").forEach { (size, label) ->
                        val isSelected = bubbleSize == size
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF334155))
                                .clickable { prefs.setBubbleSize(size) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Default Window Opacity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Window Opacity / Transparency", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("${(windowOpacity * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                }
                Text("Make the floating window see-through so games remain visible underneath", fontSize = 11.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = windowOpacity,
                    onValueChange = { prefs.setWindowOpacity(it) },
                    valueRange = 0.35f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF38BDF8),
                        activeTrackColor = Color(0xFF38BDF8)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Compact layout switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Compact Toolbox Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Optimize toolbox dimensions for smaller phone screens", fontSize = 11.sp, color = Color.LightGray)
                    }
                    Switch(
                        checked = compactLayout,
                        onCheckedChange = { prefs.setCompactLayout(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF2563EB)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // FEEDBACK & SYSTEM BEHAVIOR
        Text("FEEDBACK & AUDIO", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                // Haptics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Vibration, contentDescription = null, tint = Color(0xFF38BDF8))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Haptic Feedback", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Vibrate on button clicks and snapping", fontSize = 11.sp, color = Color.LightGray)
                        }
                    }
                    Switch(
                        checked = hapticsEnabled,
                        onCheckedChange = { prefs.setHapticsEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF2563EB)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sound
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF10B981))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Timer Alarm Sound", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Play notification sound when timer finishes", fontSize = 11.sp, color = Color.LightGray)
                        }
                    }
                    Switch(
                        checked = soundEnabled,
                        onCheckedChange = { prefs.setSoundEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF2563EB)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SYSTEM PERMISSIONS & INTEGRITY
        Text("PERMISSIONS & PRIVACY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                // Overlay settings link
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            try {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Display Over Other Apps Permission", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(if (Settings.canDrawOverlays(context)) "Granted" else "Tap to Grant in Android Settings", fontSize = 11.sp, color = if (Settings.canDrawOverlays(context)) Color(0xFF10B981) else Color(0xFFEF4444))
                    }
                    Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Privacy assurance
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "100% Private & Offline: Floating Window Pro never uploads notes, clipboard, or shortcuts to any external server. All data is persisted strictly in local device database.",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // RESET SETTINGS BUTTON
        Button(
            onClick = { showResetConfirm = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
            modifier = Modifier.fillMaxWidth().height(44.dp).testTag("reset_settings_btn")
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Reset Settings to Default", fontSize = 12.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // About & Version Footer
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Floating Window Pro v1.0", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Text("Native Jetpack Compose • Material 3", fontSize = 10.sp, color = Color.DarkGray)
        }
    }
}
