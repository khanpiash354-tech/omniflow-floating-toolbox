package com.example.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppDatabase
import com.example.data.model.CalcHistoryEntity
import com.example.util.CalculatorEngine
import kotlinx.coroutines.launch

@Composable
fun OverlayCalculatorTab(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember { AppDatabase.getInstance(context) }
    val historyList by db.calcHistoryDao().getAllHistory().collectAsState(initial = emptyList())

    var expression by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("0") }
    var showHistory by remember { mutableStateOf(false) }

    fun onInput(char: String) {
        expression += char
        val eval = CalculatorEngine.evaluate(expression)
        if (eval is CalculatorEngine.CalcResult.Success) {
            resultText = eval.formatted
        }
    }

    fun onClear() {
        expression = ""
        resultText = "0"
    }

    fun onBackspace() {
        if (expression.isNotEmpty()) {
            expression = expression.dropLast(1)
            if (expression.isEmpty()) {
                resultText = "0"
            } else {
                val eval = CalculatorEngine.evaluate(expression)
                if (eval is CalculatorEngine.CalcResult.Success) {
                    resultText = eval.formatted
                }
            }
        }
    }

    fun onEquals() {
        if (expression.isBlank()) return
        val eval = CalculatorEngine.evaluate(expression)
        when (eval) {
            is CalculatorEngine.CalcResult.Success -> {
                resultText = eval.formatted
                val finalExpr = expression
                val finalRes = eval.formatted
                scope.launch {
                    db.calcHistoryDao().insert(
                        CalcHistoryEntity(expression = finalExpr, result = finalRes)
                    )
                }
                expression = eval.formatted
            }
            is CalculatorEngine.CalcResult.Error -> {
                resultText = eval.message
            }
        }
    }

    fun copyResult() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Calculator Result", resultText)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied $resultText", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
            .testTag("overlay_calculator_tab")
    ) {
        // Display card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.End
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row {
                        IconButton(
                            onClick = { showHistory = !showHistory },
                            modifier = Modifier.size(28.dp).testTag("calc_history_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "History",
                                tint = if (showHistory) Color(0xFF38BDF8) else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { copyResult() },
                            modifier = Modifier.size(28.dp).testTag("calc_copy_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Text(
                        text = expression.ifEmpty { " " },
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = resultText,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (resultText.startsWith("Cannot") || resultText.startsWith("Invalid")) Color(0xFFEF4444) else Color(0xFF38BDF8),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        if (showHistory) {
            // History list view
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Calculation History", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        if (historyList.isNotEmpty()) {
                            IconButton(
                                onClick = {
                                    scope.launch { db.calcHistoryDao().clearAll() }
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Clear", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                    if (historyList.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No history yet", fontSize = 11.sp, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            items(historyList) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            expression = item.expression
                                            resultText = item.result
                                            showHistory = false
                                        }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(item.expression, fontSize = 11.sp, color = Color.LightGray, maxLines = 1)
                                    Text("= ${item.result}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Compact keypad
            val btnModifier = Modifier
                .height(42.dp)
                .fillMaxWidth()

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Row 1: C, ⌫, (, )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CalcKey(text = "C", color = Color(0xFFEF4444), modifier = Modifier.weight(1f), onClick = { onClear() })
                    CalcKey(icon = Icons.Default.Backspace, color = Color(0xFFF97316), modifier = Modifier.weight(1f), onClick = { onBackspace() })
                    CalcKey(text = "(", color = Color(0xFF64748B), modifier = Modifier.weight(1f), onClick = { onInput("(") })
                    CalcKey(text = ")", color = Color(0xFF64748B), modifier = Modifier.weight(1f), onClick = { onInput(")") })
                }
                // Row 2: %, ÷, ×, -
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CalcKey(text = "%", color = Color(0xFF0EA5E9), modifier = Modifier.weight(1f), onClick = { onInput("%") })
                    CalcKey(text = "÷", color = Color(0xFF0EA5E9), modifier = Modifier.weight(1f), onClick = { onInput("÷") })
                    CalcKey(text = "×", color = Color(0xFF0EA5E9), modifier = Modifier.weight(1f), onClick = { onInput("×") })
                    CalcKey(text = "-", color = Color(0xFF0EA5E9), modifier = Modifier.weight(1f), onClick = { onInput("-") })
                }
                // Row 3: 7, 8, 9, +
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CalcKey(text = "7", modifier = Modifier.weight(1f), onClick = { onInput("7") })
                    CalcKey(text = "8", modifier = Modifier.weight(1f), onClick = { onInput("8") })
                    CalcKey(text = "9", modifier = Modifier.weight(1f), onClick = { onInput("9") })
                    CalcKey(text = "+", color = Color(0xFF0EA5E9), modifier = Modifier.weight(1f), onClick = { onInput("+") })
                }
                // Row 4: 4, 5, 6, =
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CalcKey(text = "4", modifier = Modifier.weight(1f), onClick = { onInput("4") })
                    CalcKey(text = "5", modifier = Modifier.weight(1f), onClick = { onInput("5") })
                    CalcKey(text = "6", modifier = Modifier.weight(1f), onClick = { onInput("6") })
                    CalcKey(text = "=", color = Color(0xFF10B981), modifier = Modifier.weight(1f), isFilled = true, onClick = { onEquals() })
                }
                // Row 5: 1, 2, 3, 0, .
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    CalcKey(text = "1", modifier = Modifier.weight(1f), onClick = { onInput("1") })
                    CalcKey(text = "2", modifier = Modifier.weight(1f), onClick = { onInput("2") })
                    CalcKey(text = "3", modifier = Modifier.weight(1f), onClick = { onInput("3") })
                    CalcKey(text = "0", modifier = Modifier.weight(1f), onClick = { onInput("0") })
                    CalcKey(text = ".", modifier = Modifier.weight(1f), onClick = { onInput(".") })
                }
            }
        }
    }
}

@Composable
private fun CalcKey(
    text: String? = null,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    color: Color = Color.White,
    isFilled: Boolean = false,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor = if (isFilled) color else Color(0xFF1E293B)
    val contentColor = if (isFilled) Color.White else color

    Box(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag("calc_key_${text ?: "icon"}"),
        contentAlignment = Alignment.Center
    ) {
        if (text != null) {
            Text(
                text = text,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = contentColor
            )
        } else if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
