package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.service.FloatingWindowController
import com.example.util.InstalledAppsManager

@Composable
fun DashboardScreen(
    onNavigateToApps: () -> Unit,
    onNavigateToFavorites: () -> Unit,
    onNavigateToNotes: () -> Unit,
    onNavigateToCalculator: () -> Unit,
    onNavigateToTimer: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager.getInstance(context) }
    val db = remember { AppDatabase.getInstance(context) }

    val isServiceRunning by FloatingWindowController.isServiceRunning.collectAsState()
    val isBubbleVisible by FloatingWindowController.isBubbleVisible.collectAsState()
    val hasOverlayPermission = remember(isServiceRunning) { FloatingWindowController.checkOverlayPermission(context) }

    val shortcuts by db.shortcutDao().getAllShortcuts().collectAsState(initial = emptyList())
    val notes by db.noteDao().getAllNotes().collectAsState(initial = emptyList())

    val isFreeFireInstalled = remember { InstalledAppsManager.isFreeFireInstalled(context) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("dashboard_screen")
    ) {
        // App Hero Header
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Floating Window",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF2563EB))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("PRO", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            }
                        }
                        Text(
                            text = "Multitasking overlay toolbox above all apps",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }

                    // Master Service Switch
                    Switch(
                        checked = isServiceRunning,
                        onCheckedChange = { enable ->
                            if (enable) {
                                if (!hasOverlayPermission) {
                                    requestOverlayPermission(context)
                                } else {
                                    FloatingWindowController.startFloatingService(context)
                                }
                            } else {
                                FloatingWindowController.stopFloatingService(context)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF10B981),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.testTag("master_floating_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Service Status Indicator Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isServiceRunning) Color(0xFF064E3B) else Color(0xFF1E293B))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isServiceRunning) Color(0xFF10B981) else Color(0xFFEF4444))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isServiceRunning) "Overlay Active & Draggable" else "Floating Overlay Stopped",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isServiceRunning) Color(0xFFA7F3D0) else Color.LightGray
                        )
                    }

                    if (isServiceRunning) {
                        Button(
                            onClick = { FloatingWindowController.openToolbox() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.height(30.dp).testTag("open_overlay_btn")
                        ) {
                            Text("Open Toolbox", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Permission Banner (if not granted)
        if (!hasOverlayPermission) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(14.dp))
                    .testTag("overlay_permission_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Overlay Permission Required",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFFFCD34D)
                        )
                        Text(
                            text = "Required by Android to render the floating bubble & toolbox on top of games and other apps.",
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { requestOverlayPermission(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                            modifier = Modifier.height(32.dp).testTag("grant_overlay_permission_btn")
                        ) {
                            Text("Grant Permission", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Stats Overview Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatCard(
                title = "Shortcuts",
                value = "${shortcuts.size}",
                icon = Icons.Default.Apps,
                color = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToApps
            )
            StatCard(
                title = "Notes",
                value = "${notes.size}",
                icon = Icons.Default.EditNote,
                color = Color(0xFFA78BFA),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToNotes
            )
            StatCard(
                title = "Gaming",
                value = if (isFreeFireInstalled) "Free Fire" else "Ready",
                icon = Icons.Default.Gamepad,
                color = Color(0xFFF59E0B),
                modifier = Modifier.weight(1f),
                onClick = {
                    FloatingWindowController.openToolbox(com.example.service.ToolTab.GAMING)
                }
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Tool Suite Grid
        Text(
            text = "FLOATING TOOLS SUITE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ToolNavigationCard(
                title = "Installed Apps & Shortcuts",
                subtitle = "Select real installed apps to launch with 1 tap above any game or app",
                icon = Icons.Default.Apps,
                accentColor = Color(0xFF2563EB),
                onClick = onNavigateToApps
            )

            ToolNavigationCard(
                title = "Gaming Toolbox & Free Fire Companion",
                subtitle = "Game-session timer, Free Fire direct launch, DND settings, and transparent tools",
                icon = Icons.Default.Gamepad,
                accentColor = Color(0xFFF59E0B),
                onClick = {
                    FloatingWindowController.openToolbox(com.example.service.ToolTab.GAMING)
                    if (!isServiceRunning && hasOverlayPermission) {
                        FloatingWindowController.startFloatingService(context)
                    }
                }
            )

            ToolNavigationCard(
                title = "Floating Calculator",
                subtitle = "Expressions, arithmetic, percentage, parentheses, history, and clipboard copy",
                icon = Icons.Default.Calculate,
                accentColor = Color(0xFF0EA5E9),
                onClick = onNavigateToCalculator
            )

            ToolNavigationCard(
                title = "Notes & Scratchpad",
                subtitle = "Quick note taking, local Room database auto-save, search, and copy",
                icon = Icons.Default.EditNote,
                accentColor = Color(0xFF8B5CF6),
                onClick = onNavigateToNotes
            )

            ToolNavigationCard(
                title = "Timer & Stopwatch",
                subtitle = "Monotonic countdown timer with presets and stopwatch with lap times",
                icon = Icons.Default.Timer,
                accentColor = Color(0xFFEC4899),
                onClick = onNavigateToTimer
            )
        }
    }
}

private fun requestOverlayPermission(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        Toast.makeText(context, "Please enable 'Allow display over other apps'", Toast.LENGTH_LONG).show()
    } catch (_: Exception) {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
            Text(title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun ToolNavigationCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(2.dp))
                Text(subtitle, fontSize = 11.sp, color = Color.LightGray, maxLines = 2)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
        }
    }
}
