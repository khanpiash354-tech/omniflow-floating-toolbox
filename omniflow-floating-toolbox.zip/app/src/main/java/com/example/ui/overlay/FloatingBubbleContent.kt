package com.example.ui.overlay

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.util.TimerStopwatchEngine

@Composable
fun FloatingBubbleContent(
    onBubbleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTimerRunning by TimerStopwatchEngine.timerRunning.collectAsState()
    val isStopwatchRunning by TimerStopwatchEngine.stopwatchRunning.collectAsState()
    val isGamingActive by TimerStopwatchEngine.isGamingActive.collectAsState()

    val hasActiveActivity = isTimerRunning || isStopwatchRunning || isGamingActive

    val infiniteTransition = rememberInfiniteTransition(label = "bubble_glow")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (hasActiveActivity) 1.08f else 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("floating_bubble_container"),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow circle
        Box(
            modifier = Modifier
                .fillMaxSize(0.92f)
                .scale(pulseScale)
                .shadow(elevation = 10.dp, shape = CircleShape, ambientColor = Color(0xFF00E5FF), spotColor = Color(0xFF7C4DFF))
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF2563EB),
                            Color(0xFF1E1B4B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color(0xFF00E5FF),
                            Color(0xFF7C4DFF),
                            Color(0xFFFF007A),
                            Color(0xFF00E5FF)
                        )
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onBubbleClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Widgets,
                contentDescription = "Open Floating Toolbox",
                tint = Color(0xFF38BDF8),
                modifier = Modifier
                    .fillMaxSize(0.55f)
                    .testTag("floating_bubble_icon")
            )
        }

        // Active indicator dot (shows if timer or gaming is running)
        if (hasActiveActivity) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = (-3).dp, y = 3.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color(0xFF10B981))
                    .border(1.5.dp, Color.White, CircleShape)
            )
        }
    }
}
