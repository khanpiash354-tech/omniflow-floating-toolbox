package com.example.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PreferencesManager
import com.example.service.FloatingWindowController
import com.example.service.ToolTab

@Composable
fun FloatingToolboxContent(
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onResizeToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager.getInstance(context) }
    val windowOpacity by prefs.windowOpacity.collectAsState()
    val activeTab by FloatingWindowController.activeTab.collectAsState()
    val isExpanded by FloatingWindowController.isExpandedMode.collectAsState()

    var showOpacitySlider by remember { mutableStateOf(false) }

    val tabs = listOf(
        Triple(ToolTab.APPS, "Apps", Icons.Default.Apps),
        Triple(ToolTab.CALCULATOR, "Calc", Icons.Default.Calculate),
        Triple(ToolTab.GAMING, "Game", Icons.Default.Gamepad),
        Triple(ToolTab.NOTES, "Notes", Icons.Default.EditNote),
        Triple(ToolTab.TIMER, "Timer", Icons.Default.Timer),
        Triple(ToolTab.TOOLS, "Tools", Icons.Default.Widgets)
    )

    Card(
        modifier = modifier
            .fillMaxSize()
            .shadow(16.dp, RoundedCornerShape(16.dp))
            .border(1.5.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .testTag("floating_toolbox_window"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1E293B))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF38BDF8))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Floating Window Pro",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Opacity control toggle
                    IconButton(
                        onClick = { showOpacitySlider = !showOpacitySlider },
                        modifier = Modifier.size(28.dp).testTag("toolbox_opacity_toggle_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Opacity,
                            contentDescription = "Transparency",
                            tint = if (showOpacitySlider) Color(0xFF38BDF8) else Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Resize / Maximize toggle
                    IconButton(
                        onClick = onResizeToggle,
                        modifier = Modifier.size(28.dp).testTag("toolbox_resize_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = "Resize",
                            tint = Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Minimize button
                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier.size(28.dp).testTag("toolbox_minimize_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Minimize,
                            contentDescription = "Minimize",
                            tint = Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Close button
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(28.dp).testTag("toolbox_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Quick Opacity Slider Overlay in header
            if (showOpacitySlider) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E1B4B))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Opacity: ${(windowOpacity * 100).toInt()}%", fontSize = 10.sp, color = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Slider(
                        value = windowOpacity,
                        onValueChange = { prefs.setWindowOpacity(it) },
                        valueRange = 0.35f..1.0f,
                        modifier = Modifier.weight(1f).height(24.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF38BDF8),
                            activeTrackColor = Color(0xFF38BDF8)
                        )
                    )
                }
            }

            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = tabs.indexOfFirst { it.first == activeTab }.coerceAtLeast(0),
                containerColor = Color(0xFF1E293B),
                contentColor = Color(0xFF38BDF8),
                edgePadding = 4.dp,
                indicator = { tabPositions ->
                    val index = tabs.indexOfFirst { it.first == activeTab }.coerceAtLeast(0)
                    if (index < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[index]),
                            color = Color(0xFF38BDF8),
                            height = 2.dp
                        )
                    }
                },
                divider = {}
            ) {
                tabs.forEach { (tab, title, icon) ->
                    val isSelected = activeTab == tab
                    Tab(
                        selected = isSelected,
                        onClick = { FloatingWindowController.selectTab(tab) },
                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp).testTag("tab_${tab.name.lowercase()}"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (isSelected) Color(0xFF38BDF8) else Color.Gray
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color.Gray
                                )
                            }
                        }
                    )
                }
            }

            // Active Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeTab) {
                    ToolTab.APPS -> OverlayAppsTab(onAppLaunched = onMinimize)
                    ToolTab.CALCULATOR -> OverlayCalculatorTab()
                    ToolTab.GAMING -> OverlayGamingTab(onSwitchTab = { FloatingWindowController.selectTab(it) })
                    ToolTab.NOTES -> OverlayNotesTab()
                    ToolTab.TIMER -> OverlayTimerTab()
                    ToolTab.TOOLS -> OverlayToolsTab(onSwitchTab = { FloatingWindowController.selectTab(it) })
                }
            }
        }
    }
}
