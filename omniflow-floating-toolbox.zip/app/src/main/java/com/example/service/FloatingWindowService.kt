package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.ui.overlay.FloatingBubbleContent
import com.example.ui.overlay.FloatingToolboxContent
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingWindowService : Service() {

    companion object {
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val ACTION_TOGGLE_BUBBLE = "com.example.service.ACTION_TOGGLE_BUBBLE"
        const val ACTION_OPEN_TOOLBOX = "com.example.service.ACTION_OPEN_TOOLBOX"
        const val ACTION_CLOSE_TOOLBOX = "com.example.service.ACTION_CLOSE_TOOLBOX"

        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "floating_window_service_channel"
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: PreferencesManager
    private lateinit var database: AppDatabase
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var bubbleLifecycleOwner: OverlayLifecycleOwner? = null
    private var bubbleComposeView: ComposeView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var toolboxLifecycleOwner: OverlayLifecycleOwner? = null
    private var toolboxComposeView: ComposeView? = null
    private var toolboxParams: WindowManager.LayoutParams? = null

    private var isBubbleAttached = false
    private var isToolboxAttached = false
    private var opacityJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = PreferencesManager.getInstance(this)
        database = AppDatabase.getInstance(this)

        createNotificationChannel()
        startForegroundWithNotification()

        FloatingWindowController.setServiceState(true)

        initBubble()
        initToolbox()
        observeState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_BUBBLE -> {
                val current = FloatingWindowController.isBubbleVisible.value
                FloatingWindowController.setBubbleVisibility(!current)
                updateBubbleVisibility(!current)
            }
            ACTION_OPEN_TOOLBOX -> {
                FloatingWindowController.openToolbox()
            }
            ACTION_CLOSE_TOOLBOX -> {
                FloatingWindowController.closeToolbox()
            }
            ACTION_START -> {
                showBubble()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Window Active",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Controls for the Floating Window Pro toolbox and bubble"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleIntent = Intent(this, FloatingWindowService::class.java).apply {
            action = ACTION_TOGGLE_BUBBLE
        }
        val togglePendingIntent = PendingIntent.getService(
            this,
            1,
            toggleIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingWindowService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Window Pro is Active")
            .setContentText("Tap to open dashboard or use actions below")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(R.mipmap.ic_launcher, "Toggle Bubble", togglePendingIntent)
            .addAction(R.mipmap.ic_launcher, "Close", stopPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initBubble() {
        if (!Settings.canDrawOverlays(this)) return

        bubbleLifecycleOwner = OverlayLifecycleOwner().apply {
            onCreate()
            onStart()
            onResume()
        }

        val density = resources.displayMetrics.density
        val sizePx = (prefs.bubbleSize.value * density).toInt()

        val savedPos = prefs.getBubblePosition()
        val metrics = resources.displayMetrics
        val initialX = if (savedPos.first >= 0) savedPos.first else 16
        val initialY = if (savedPos.second >= 0) savedPos.second else (metrics.heightPixels / 3)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initialX
            y = initialY
        }

        bubbleComposeView = ComposeView(this).apply {
            bubbleLifecycleOwner?.let { owner ->
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
            }
            setContent {
                MyApplicationTheme {
                    FloatingBubbleContent(
                        onBubbleClick = {
                            FloatingWindowController.toggleToolbox()
                        }
                    )
                }
            }

            setupBubbleTouchListener(this)
        }

        showBubble()
    }

    private fun setupBubbleTouchListener(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isMoving = false

        view.setOnTouchListener { _, event ->
            val params = bubbleParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isMoving = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()

                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isMoving = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        if (isBubbleAttached) {
                            try {
                                windowManager.updateViewLayout(view, params)
                            } catch (_: Exception) {}
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isMoving) {
                        // Click action!
                        FloatingWindowController.toggleToolbox()
                    } else {
                        // Snap to nearest screen edge (left or right)
                        val metrics = resources.displayMetrics
                        val screenWidth = metrics.widthPixels
                        val bubbleWidth = view.width.coerceAtLeast(100)
                        val snapToRight = (params.x + bubbleWidth / 2) > (screenWidth / 2)
                        val targetX = if (snapToRight) screenWidth - bubbleWidth - 16 else 16

                        params.x = targetX
                        // Keep within vertical bounds
                        val maxY = metrics.heightPixels - view.height - 80
                        params.y = params.y.coerceIn(80, maxY)

                        if (isBubbleAttached) {
                            try {
                                windowManager.updateViewLayout(view, params)
                            } catch (_: Exception) {}
                        }
                        prefs.saveBubblePosition(params.x, params.y)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun initToolbox() {
        if (!Settings.canDrawOverlays(this)) return

        toolboxLifecycleOwner = OverlayLifecycleOwner().apply {
            onCreate()
            onStart()
            onResume()
        }

        val metrics = resources.displayMetrics
        val density = metrics.density

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val defaultWidthPx = (340 * density).toInt().coerceAtMost((metrics.widthPixels * 0.95).toInt())
        val defaultHeightPx = (480 * density).toInt().coerceAtMost((metrics.heightPixels * 0.85).toInt())

        toolboxParams = WindowManager.LayoutParams(
            defaultWidthPx,
            defaultHeightPx,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            alpha = prefs.windowOpacity.value
        }

        toolboxComposeView = ComposeView(this).apply {
            toolboxLifecycleOwner?.let { owner ->
                setViewTreeLifecycleOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
            }
            setContent {
                MyApplicationTheme {
                    FloatingToolboxContent(
                        onClose = {
                            FloatingWindowController.closeToolbox()
                        },
                        onMinimize = {
                            FloatingWindowController.closeToolbox()
                        },
                        onResizeToggle = {
                            toggleToolboxSize()
                        }
                    )
                }
            }
        }
    }

    private fun toggleToolboxSize() {
        val params = toolboxParams ?: return
        val view = toolboxComposeView ?: return
        if (!isToolboxAttached) return

        val metrics = resources.displayMetrics
        val density = metrics.density
        val isExpanded = FloatingWindowController.isExpandedMode.value

        if (!isExpanded) {
            // Expand to larger view
            params.width = (metrics.widthPixels * 0.95).toInt()
            params.height = (metrics.heightPixels * 0.85).toInt()
            FloatingWindowController.setExpandedMode(true)
        } else {
            // Revert to standard compact view
            params.width = (340 * density).toInt().coerceAtMost((metrics.widthPixels * 0.95).toInt())
            params.height = (480 * density).toInt().coerceAtMost((metrics.heightPixels * 0.85).toInt())
            FloatingWindowController.setExpandedMode(false)
        }

        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: Exception) {}
    }

    private fun observeState() {
        serviceScope.launch {
            FloatingWindowController.isToolboxOpen.collectLatest { isOpen ->
                if (isOpen) {
                    showToolbox()
                } else {
                    hideToolbox()
                }
            }
        }

        serviceScope.launch {
            FloatingWindowController.isBubbleVisible.collectLatest { isVisible ->
                updateBubbleVisibility(isVisible)
            }
        }

        serviceScope.launch {
            prefs.windowOpacity.collectLatest { opacity ->
                toolboxParams?.let { params ->
                    params.alpha = opacity
                    if (isToolboxAttached && toolboxComposeView != null) {
                        try {
                            windowManager.updateViewLayout(toolboxComposeView, params)
                        } catch (_: Exception) {}
                    }
                }
            }
        }

        serviceScope.launch {
            prefs.bubbleSize.collectLatest { sizeDp ->
                val density = resources.displayMetrics.density
                val sizePx = (sizeDp * density).toInt()
                bubbleParams?.let { params ->
                    params.width = sizePx
                    params.height = sizePx
                    if (isBubbleAttached && bubbleComposeView != null) {
                        try {
                            windowManager.updateViewLayout(bubbleComposeView, params)
                        } catch (_: Exception) {}
                    }
                }
            }
        }
    }

    private fun showBubble() {
        if (!isBubbleAttached && bubbleComposeView != null && bubbleParams != null) {
            try {
                windowManager.addView(bubbleComposeView, bubbleParams)
                isBubbleAttached = true
            } catch (e: Exception) {
                isBubbleAttached = false
            }
        }
    }

    private fun updateBubbleVisibility(visible: Boolean) {
        if (visible) {
            if (!isBubbleAttached) showBubble()
            bubbleComposeView?.visibility = View.VISIBLE
        } else {
            bubbleComposeView?.visibility = View.GONE
        }
    }

    private fun showToolbox() {
        if (!isToolboxAttached && toolboxComposeView != null && toolboxParams != null) {
            try {
                windowManager.addView(toolboxComposeView, toolboxParams)
                isToolboxAttached = true
            } catch (e: Exception) {
                isToolboxAttached = false
            }
        }
    }

    private fun hideToolbox() {
        if (isToolboxAttached && toolboxComposeView != null) {
            try {
                windowManager.removeView(toolboxComposeView)
                isToolboxAttached = false
            } catch (e: Exception) {
                isToolboxAttached = false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        FloatingWindowController.setServiceState(false)
        serviceScope.cancel()

        if (isBubbleAttached && bubbleComposeView != null) {
            try {
                windowManager.removeView(bubbleComposeView)
            } catch (_: Exception) {}
            isBubbleAttached = false
        }
        bubbleLifecycleOwner?.onDestroy()

        if (isToolboxAttached && toolboxComposeView != null) {
            try {
                windowManager.removeView(toolboxComposeView)
            } catch (_: Exception) {}
            isToolboxAttached = false
        }
        toolboxLifecycleOwner?.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
