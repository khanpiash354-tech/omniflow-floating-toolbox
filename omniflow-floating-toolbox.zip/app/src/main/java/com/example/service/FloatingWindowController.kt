package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.example.data.PreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ToolTab(val title: String) {
    APPS("Apps"),
    CALCULATOR("Calculator"),
    GAMING("Gaming Hub"),
    NOTES("Notes"),
    TIMER("Timer"),
    TOOLS("Tools")
}

object FloatingWindowController {
    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _isBubbleVisible = MutableStateFlow(true)
    val isBubbleVisible: StateFlow<Boolean> = _isBubbleVisible.asStateFlow()

    private val _isToolboxOpen = MutableStateFlow(false)
    val isToolboxOpen: StateFlow<Boolean> = _isToolboxOpen.asStateFlow()

    private val _activeTab = MutableStateFlow(ToolTab.APPS)
    val activeTab: StateFlow<ToolTab> = _activeTab.asStateFlow()

    private val _isExpandedMode = MutableStateFlow(false)
    val isExpandedMode: StateFlow<Boolean> = _isExpandedMode.asStateFlow()

    // Floating window actions for inter-process and in-app synchronization
    fun checkOverlayPermission(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun startFloatingService(context: Context): Boolean {
        if (!checkOverlayPermission(context)) {
            return false
        }
        val intent = Intent(context, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        _isServiceRunning.value = true
        _isBubbleVisible.value = true
        PreferencesManager.getInstance(context).setServiceEnabled(true)
        return true
    }

    fun stopFloatingService(context: Context) {
        val intent = Intent(context, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_STOP
        }
        context.startService(intent)
        _isServiceRunning.value = false
        _isToolboxOpen.value = false
        _isBubbleVisible.value = false
        PreferencesManager.getInstance(context).setServiceEnabled(false)
    }

    fun setServiceState(running: Boolean) {
        _isServiceRunning.value = running
        if (!running) {
            _isToolboxOpen.value = false
            _isBubbleVisible.value = false
        }
    }

    fun setBubbleVisibility(visible: Boolean) {
        _isBubbleVisible.value = visible
    }

    fun openToolbox(tab: ToolTab = ToolTab.APPS) {
        _activeTab.value = tab
        _isToolboxOpen.value = true
    }

    fun closeToolbox() {
        _isToolboxOpen.value = false
    }

    fun toggleToolbox() {
        _isToolboxOpen.value = !_isToolboxOpen.value
    }

    fun selectTab(tab: ToolTab) {
        _activeTab.value = tab
    }

    fun toggleExpandedMode() {
        _isExpandedMode.value = !_isExpandedMode.value
    }

    fun setExpandedMode(expanded: Boolean) {
        _isExpandedMode.value = expanded
    }
}
