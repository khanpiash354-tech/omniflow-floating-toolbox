package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("floating_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SERVICE_ENABLED = "service_enabled"
        private const val KEY_BUBBLE_SIZE = "bubble_size" // dp, default 56
        private const val KEY_OPACITY = "window_opacity" // 0.3f to 1.0f, default 0.95f
        private const val KEY_BUBBLE_X = "bubble_pos_x"
        private const val KEY_BUBBLE_Y = "bubble_pos_y"
        private const val KEY_SNAP_TO_EDGE = "snap_to_edge"
        private const val KEY_HAPTICS = "haptics_enabled"
        private const val KEY_SOUND = "sound_enabled"
        private const val KEY_COMPACT_LAYOUT = "compact_layout"
        private const val KEY_THEME = "app_theme" // "system", "dark", "light", "neon"

        @Volatile
        private var INSTANCE: PreferencesManager? = null

        fun getInstance(context: Context): PreferencesManager {
            return INSTANCE ?: synchronized(this) {
                val inst = PreferencesManager(context.applicationContext)
                INSTANCE = inst
                inst
            }
        }
    }

    private val _serviceEnabled = MutableStateFlow(prefs.getBoolean(KEY_SERVICE_ENABLED, false))
    val serviceEnabled: StateFlow<Boolean> = _serviceEnabled.asStateFlow()

    private val _bubbleSize = MutableStateFlow(prefs.getInt(KEY_BUBBLE_SIZE, 56))
    val bubbleSize: StateFlow<Int> = _bubbleSize.asStateFlow()

    private val _windowOpacity = MutableStateFlow(prefs.getFloat(KEY_OPACITY, 0.95f))
    val windowOpacity: StateFlow<Float> = _windowOpacity.asStateFlow()

    private val _hapticsEnabled = MutableStateFlow(prefs.getBoolean(KEY_HAPTICS, true))
    val hapticsEnabled: StateFlow<Boolean> = _hapticsEnabled.asStateFlow()

    private val _soundEnabled = MutableStateFlow(prefs.getBoolean(KEY_SOUND, true))
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _compactLayout = MutableStateFlow(prefs.getBoolean(KEY_COMPACT_LAYOUT, false))
    val compactLayout: StateFlow<Boolean> = _compactLayout.asStateFlow()

    private val _appTheme = MutableStateFlow(prefs.getString(KEY_THEME, "dark") ?: "dark")
    val appTheme: StateFlow<String> = _appTheme.asStateFlow()

    fun setServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
        _serviceEnabled.value = enabled
    }

    fun setBubbleSize(sizeDp: Int) {
        val clamped = sizeDp.coerceIn(40, 72)
        prefs.edit().putInt(KEY_BUBBLE_SIZE, clamped).apply()
        _bubbleSize.value = clamped
    }

    fun setWindowOpacity(opacity: Float) {
        val clamped = opacity.coerceIn(0.35f, 1.0f)
        prefs.edit().putFloat(KEY_OPACITY, clamped).apply()
        _windowOpacity.value = clamped
    }

    fun saveBubblePosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_BUBBLE_X, x).putInt(KEY_BUBBLE_Y, y).apply()
    }

    fun getBubblePosition(): Pair<Int, Int> {
        val x = prefs.getInt(KEY_BUBBLE_X, -1)
        val y = prefs.getInt(KEY_BUBBLE_Y, -1)
        return Pair(x, y)
    }

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HAPTICS, enabled).apply()
        _hapticsEnabled.value = enabled
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOUND, enabled).apply()
        _soundEnabled.value = enabled
    }

    fun setCompactLayout(compact: Boolean) {
        prefs.edit().putBoolean(KEY_COMPACT_LAYOUT, compact).apply()
        _compactLayout.value = compact
    }

    fun setAppTheme(theme: String) {
        prefs.edit().putString(KEY_THEME, theme).apply()
        _appTheme.value = theme
    }

    fun resetDefaults() {
        prefs.edit().clear().apply()
        _serviceEnabled.value = false
        _bubbleSize.value = 56
        _windowOpacity.value = 0.95f
        _hapticsEnabled.value = true
        _soundEnabled.value = true
        _compactLayout.value = false
        _appTheme.value = "dark"
    }
}
