package com.example.data.model

import android.graphics.drawable.Drawable

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val iconDrawable: Drawable? = null,
    val isSystemApp: Boolean = false,
    val isGame: Boolean = false,
    val isFreeFire: Boolean = false
)
