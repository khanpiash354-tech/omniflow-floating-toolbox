package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.CalcHistoryDao
import com.example.data.dao.NoteDao
import com.example.data.dao.ShortcutDao
import com.example.data.model.CalcHistoryEntity
import com.example.data.model.NoteEntity
import com.example.data.model.ShortcutEntity

@Database(
    entities = [NoteEntity::class, CalcHistoryEntity::class, ShortcutEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun calcHistoryDao(): CalcHistoryDao
    abstract fun shortcutDao(): ShortcutDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "floating_window_pro.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
