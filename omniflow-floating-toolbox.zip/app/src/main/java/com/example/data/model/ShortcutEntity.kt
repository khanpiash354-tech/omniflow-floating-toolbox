package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shortcuts")
data class ShortcutEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val appName: String,
    val isFavorite: Boolean = false,
    val orderIndex: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)
