package com.example.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import java.util.Stack

object CalculatorEngine {

    sealed class CalcResult {
        data class Success(val value: Double, val formatted: String) : CalcResult()
        data class Error(val message: String) : CalcResult()
    }

    private val decimalFormat = DecimalFormat("#,##0.########", DecimalFormatSymbols(Locale.US))

    fun formatNumber(number: Double): String {
        return if (number == number.toLong().toDouble() && !number.isInfinite() && !number.isNaN()) {
            number.toLong().toString()
        } else {
            decimalFormat.format(number)
        }
    }

    fun evaluate(expression: String): CalcResult {
        if (expression.isBlank()) return CalcResult.Success(0.0, "0")

        return try {
            val tokens = tokenize(expression)
            if (tokens.isEmpty()) return CalcResult.Success(0.0, "0")
            val postfix = infixToPostfix(tokens)
            val result = evaluatePostfix(postfix)
            CalcResult.Success(result, formatNumber(result))
        } catch (e: ArithmeticException) {
            CalcResult.Error(e.message ?: "Calculation error")
        } catch (e: IllegalArgumentException) {
            CalcResult.Error(e.message ?: "Invalid expression")
        } catch (e: Exception) {
            CalcResult.Error("Invalid expression")
        }
    }

    private fun tokenize(raw: String): List<String> {
        val sanitized = raw.replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(" ", "")

        val tokens = mutableListOf<String>()
        var i = 0
        val n = sanitized.length

        while (i < n) {
            val c = sanitized[i]

            // Numbers, decimals, percentages
            if (c.isDigit() || c == '.') {
                val sb = StringBuilder()
                while (i < n && (sanitized[i].isDigit() || sanitized[i] == '.')) {
                    sb.append(sanitized[i])
                    i++
                }
                tokens.add(sb.toString())
                continue
            }

            // Unary minus handling (at start or after operator / open paren)
            if (c == '-') {
                val prev = tokens.lastOrNull()
                if (prev == null || prev == "(" || isOperator(prev)) {
                    // Check if followed by digit
                    if (i + 1 < n && (sanitized[i + 1].isDigit() || sanitized[i + 1] == '.')) {
                        val sb = StringBuilder("-")
                        i++
                        while (i < n && (sanitized[i].isDigit() || sanitized[i] == '.')) {
                            sb.append(sanitized[i])
                            i++
                        }
                        tokens.add(sb.toString())
                        continue
                    }
                }
            }

            if (c == '%') {
                tokens.add("%")
                i++
                continue
            }

            if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')') {
                tokens.add(c.toString())
                i++
                continue
            }

            i++
        }
        return tokens
    }

    private fun isOperator(s: String): Boolean =
        s == "+" || s == "-" || s == "*" || s == "/" || s == "%"

    private fun precedence(op: String): Int = when (op) {
        "+", "-" -> 1
        "*", "/", "%" -> 2
        else -> 0
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = Stack<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> output.add(token)
                token == "(" -> stack.push(token)
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.peek() != "(") {
                        output.add(stack.pop())
                    }
                    if (stack.isNotEmpty() && stack.peek() == "(") {
                        stack.pop()
                    } else {
                        throw IllegalArgumentException("Mismatched parentheses")
                    }
                }
                isOperator(token) -> {
                    while (stack.isNotEmpty() && stack.peek() != "(" &&
                        precedence(stack.peek()) >= precedence(token)
                    ) {
                        output.add(stack.pop())
                    }
                    stack.push(token)
                }
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.pop()
            if (top == "(" || top == ")") {
                throw IllegalArgumentException("Mismatched parentheses")
            }
            output.add(top)
        }

        return output
    }

    private fun evaluatePostfix(postfix: List<String>): Double {
        val stack = Stack<Double>()

        for (token in postfix) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.push(num)
            } else if (token == "%") {
                if (stack.isEmpty()) throw IllegalArgumentException("Invalid percentage")
                val a = stack.pop()
                stack.push(a / 100.0)
            } else if (isOperator(token)) {
                if (stack.size < 2) throw IllegalArgumentException("Invalid expression")
                val b = stack.pop()
                val a = stack.pop()

                val res = when (token) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> {
                        if (b == 0.0) throw ArithmeticException("Cannot divide by 0")
                        a / b
                    }
                    else -> 0.0
                }
                stack.push(res)
            }
        }

        if (stack.size != 1) throw IllegalArgumentException("Invalid expression")
        val result = stack.pop()
        if (result.isNaN()) throw ArithmeticException("Result is not a number")
        if (result.isInfinite()) throw ArithmeticException("Cannot divide by 0")
        return result
    }
}
