package com.example.util

import android.content.Context
import android.media.RingtoneManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class LapRecord(
    val lapIndex: Int,
    val lapTimeMs: Long,
    val totalTimeMs: Long
)

object TimerStopwatchEngine {
    private val scope = CoroutineScope(Dispatchers.Main)

    // Stopwatch State
    private var stopwatchJob: Job? = null
    private var stopwatchBaseTime: Long = 0L
    private var stopwatchAccumulatedMs: Long = 0L

    private val _stopwatchRunning = MutableStateFlow(false)
    val stopwatchRunning: StateFlow<Boolean> = _stopwatchRunning.asStateFlow()

    private val _stopwatchElapsedMs = MutableStateFlow(0L)
    val stopwatchElapsedMs: StateFlow<Boolean> = _stopwatchRunning.asStateFlow()
    val stopwatchTimeMs: StateFlow<Long> = _stopwatchElapsedMs.asStateFlow()

    private val _laps = MutableStateFlow<List<LapRecord>>(emptyList())
    val laps: StateFlow<List<LapRecord>> = _laps.asStateFlow()

    // Countdown Timer State
    private var timerJob: Job? = null
    private var timerTotalDurationMs: Long = 0L
    private var timerRemainingMs: Long = 0L
    private var timerTargetEndTime: Long = 0L

    private val _timerRunning = MutableStateFlow(false)
    val timerRunning: StateFlow<Boolean> = _timerRunning.asStateFlow()

    private val _timerRemaining = MutableStateFlow(0L)
    val timerRemaining: StateFlow<Long> = _timerRemaining.asStateFlow()

    private val _timerFinishedEvent = MutableStateFlow(false)
    val timerFinishedEvent: StateFlow<Boolean> = _timerFinishedEvent.asStateFlow()

    // Gaming session timer (automatically records gaming duration)
    private var gamingStartTime: Long = 0L
    private var gamingJob: Job? = null
    private val _gamingDurationMs = MutableStateFlow(0L)
    val gamingDurationMs: StateFlow<Long> = _gamingDurationMs.asStateFlow()
    private val _isGamingActive = MutableStateFlow(false)
    val isGamingActive: StateFlow<Boolean> = _isGamingActive.asStateFlow()

    fun startStopwatch() {
        if (_stopwatchRunning.value) return
        stopwatchBaseTime = SystemClock.elapsedRealtime()
        _stopwatchRunning.value = true

        stopwatchJob = scope.launch {
            while (isActive && _stopwatchRunning.value) {
                val current = SystemClock.elapsedRealtime()
                _stopwatchElapsedMs.value = stopwatchAccumulatedMs + (current - stopwatchBaseTime)
                delay(30)
            }
        }
    }

    fun pauseStopwatch() {
        if (!_stopwatchRunning.value) return
        val current = SystemClock.elapsedRealtime()
        stopwatchAccumulatedMs += (current - stopwatchBaseTime)
        _stopwatchElapsedMs.value = stopwatchAccumulatedMs
        _stopwatchRunning.value = false
        stopwatchJob?.cancel()
    }

    fun resetStopwatch() {
        _stopwatchRunning.value = false
        stopwatchJob?.cancel()
        stopwatchAccumulatedMs = 0L
        _stopwatchElapsedMs.value = 0L
        _laps.value = emptyList()
    }

    fun recordLap() {
        val totalMs = _stopwatchElapsedMs.value
        val lapList = _laps.value
        val prevTotal = if (lapList.isNotEmpty()) lapList.first().totalTimeMs else 0L
        val lapMs = (totalMs - prevTotal).coerceAtLeast(0L)

        val newRecord = LapRecord(
            lapIndex = lapList.size + 1,
            lapTimeMs = lapMs,
            totalTimeMs = totalMs
        )
        _laps.value = listOf(newRecord) + lapList
    }

    fun setTimer(hours: Int, minutes: Int, seconds: Int) {
        val totalMs = (hours * 3600L + minutes * 60L + seconds) * 1000L
        timerTotalDurationMs = totalMs
        timerRemainingMs = totalMs
        _timerRemaining.value = totalMs
        _timerRunning.value = false
        timerJob?.cancel()
        _timerFinishedEvent.value = false
    }

    fun startTimer(context: Context? = null) {
        if (_timerRunning.value || timerRemainingMs <= 0L) return

        timerTargetEndTime = SystemClock.elapsedRealtime() + timerRemainingMs
        _timerRunning.value = true
        _timerFinishedEvent.value = false

        timerJob = scope.launch {
            while (isActive && _timerRunning.value) {
                val now = SystemClock.elapsedRealtime()
                val left = timerTargetEndTime - now
                if (left <= 0) {
                    _timerRemaining.value = 0L
                    timerRemainingMs = 0L
                    _timerRunning.value = false
                    _timerFinishedEvent.value = true
                    context?.let { notifyTimerFinished(it) }
                    break
                } else {
                    _timerRemaining.value = left
                    timerRemainingMs = left
                }
                delay(100)
            }
        }
    }

    fun pauseTimer() {
        if (!_timerRunning.value) return
        val now = SystemClock.elapsedRealtime()
        timerRemainingMs = (timerTargetEndTime - now).coerceAtLeast(0L)
        _timerRemaining.value = timerRemainingMs
        _timerRunning.value = false
        timerJob?.cancel()
    }

    fun resetTimer() {
        _timerRunning.value = false
        timerJob?.cancel()
        timerRemainingMs = timerTotalDurationMs
        _timerRemaining.value = timerTotalDurationMs
        _timerFinishedEvent.value = false
    }

    fun clearTimerFinishedEvent() {
        _timerFinishedEvent.value = false
    }

    // Gaming Session Live Tracker
    fun startGamingSession() {
        if (_isGamingActive.value) return
        gamingStartTime = SystemClock.elapsedRealtime()
        _isGamingActive.value = true
        gamingJob = scope.launch {
            while (isActive && _isGamingActive.value) {
                _gamingDurationMs.value = SystemClock.elapsedRealtime() - gamingStartTime
                delay(1000)
            }
        }
    }

    fun stopGamingSession() {
        _isGamingActive.value = false
        gamingJob?.cancel()
    }

    fun resetGamingSession() {
        stopGamingSession()
        _gamingDurationMs.value = 0L
    }

    private fun notifyTimerFinished(context: Context) {
        try {
            // Play default notification sound
            val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val ringtone = RingtoneManager.getRingtone(context.applicationContext, notificationUri)
            ringtone?.play()

            // Vibrate
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1)
                )
            }
        } catch (_: Exception) {}
    }

    fun formatStopwatch(ms: Long): String {
        val totalSec = ms / 1000
        val millis = (ms % 1000) / 10
        val seconds = totalSec % 60
        val minutes = (totalSec / 60) % 60
        val hours = totalSec / 3600

        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d.%02d", hours, minutes, seconds, millis)
        } else {
            String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, millis)
        }
    }

    fun formatTimer(ms: Long): String {
        val totalSec = (ms + 999) / 1000
        val seconds = totalSec % 60
        val minutes = (totalSec / 60) % 60
        val hours = totalSec / 3600

        return if (hours > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }
}
