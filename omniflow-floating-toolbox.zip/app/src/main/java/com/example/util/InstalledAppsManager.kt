package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import com.example.data.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

object InstalledAppsManager {
    private const val TAG = "InstalledAppsManager"
    private val iconCache = ConcurrentHashMap<String, Drawable>()

    private val FREE_FIRE_PACKAGES = setOf(
        "com.dts.freefireth",
        "com.dts.freefiremax"
    )

    private val KNOWN_GAME_PACKAGES = setOf(
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.tencent.ig",
        "com.pubg.imobile",
        "com.pubg.krmobile",
        "com.roblox.client",
        "com.miHoYo.GenshinImpact",
        "com.epicgames.fortnite",
        "com.activision.callofduty.shooter",
        "com.mojang.minecraftpe",
        "com.supercell.clashofclans",
        "com.supercell.clashroyale",
        "com.supercell.brawlstars",
        "com.riotgames.league.wildrift",
        "com.ea.gp.apexlegendsmobilefps"
    )

    suspend fun getInstalledLauncherApps(context: Context): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PackageManager.MATCH_ALL
        } else {
            0
        }

        val resolveInfos = try {
            pm.queryIntentActivities(intent, flags)
        } catch (e: Exception) {
            Log.e(TAG, "Error querying launcher intents", e)
            emptyList()
        }

        val seenPackages = HashSet<String>()
        val apps = mutableListOf<InstalledAppInfo>()

        for (resolveInfo in resolveInfos) {
            val pkgName = resolveInfo.activityInfo.packageName
            // Skip duplicate packages or own app
            if (pkgName == context.packageName || seenPackages.contains(pkgName)) {
                continue
            }
            seenPackages.add(pkgName)

            val appLabel = try {
                resolveInfo.loadLabel(pm).toString()
            } catch (e: Exception) {
                pkgName
            }

            val icon = try {
                resolveInfo.loadIcon(pm).also {
                    iconCache[pkgName] = it
                }
            } catch (e: Exception) {
                null
            }

            val appInfo = resolveInfo.activityInfo.applicationInfo
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isFreeFire = FREE_FIRE_PACKAGES.contains(pkgName) ||
                    appLabel.contains("Free Fire", ignoreCase = true)
            val isGame = isFreeFire ||
                    KNOWN_GAME_PACKAGES.contains(pkgName) ||
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                            appInfo.category == ApplicationInfo.CATEGORY_GAME)

            apps.add(
                InstalledAppInfo(
                    packageName = pkgName,
                    appName = appLabel,
                    iconDrawable = icon,
                    isSystemApp = isSystem,
                    isGame = isGame,
                    isFreeFire = isFreeFire
                )
            )
        }

        // Sort alphabetically, placing games & favorites accessible
        apps.sortedWith(compareByDescending<InstalledAppInfo> { it.isFreeFire }
            .thenBy { it.appName.lowercase() })
    }

    fun getAppIcon(context: Context, packageName: String): Drawable? {
        iconCache[packageName]?.let { return it }
        return try {
            val pm = context.packageManager
            val icon = pm.getApplicationIcon(packageName)
            iconCache[packageName] = icon
            icon
        } catch (e: Exception) {
            null
        }
    }

    fun isAppInstalled(context: Context, packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun isFreeFireInstalled(context: Context): Boolean {
        return FREE_FIRE_PACKAGES.any { isAppInstalled(context, it) }
    }

    fun getFreeFirePackage(context: Context): String? {
        return FREE_FIRE_PACKAGES.firstOrNull { isAppInstalled(context, it) }
    }

    fun launchApp(context: Context, packageName: String): Boolean {
        return try {
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(launchIntent)
                true
            } else {
                Log.w(TAG, "No launch intent found for $packageName")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch $packageName", e)
            false
        }
    }

    fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
