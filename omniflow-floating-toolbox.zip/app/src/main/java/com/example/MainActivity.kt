package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AppsManagerScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TimerScreen
import com.example.ui.theme.MyApplicationTheme

enum class ScreenTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Home", Icons.Default.Dashboard),
    APPS("Apps", Icons.Default.Apps),
    NOTES("Notes", Icons.Default.EditNote),
    CALCULATOR("Calc", Icons.Default.Calculate),
    TIMER("Timer", Icons.Default.Timer),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private var currentTabState = mutableStateOf(ScreenTab.DASHBOARD)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)

        setContent {
            MyApplicationTheme {
                MainAppContainer(
                    currentTab = currentTabState.value,
                    onSelectTab = { currentTabState.value = it }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val target = intent?.getStringExtra("NAV_TARGET")
        when (target) {
            "APPS" -> currentTabState.value = ScreenTab.APPS
            "NOTES" -> currentTabState.value = ScreenTab.NOTES
            "CALC" -> currentTabState.value = ScreenTab.CALCULATOR
            "TIMER" -> currentTabState.value = ScreenTab.TIMER
        }
    }
}

@Composable
fun MainAppContainer(
    currentTab: ScreenTab,
    onSelectTab: (ScreenTab) -> Unit
) {
    // Notification permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Back handler returns to dashboard when on secondary tabs
    BackHandler(enabled = currentTab != ScreenTab.DASHBOARD) {
        onSelectTab(ScreenTab.DASHBOARD)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color(0xFF0B0F17),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1E293B),
                contentColor = Color(0xFF38BDF8),
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_navigation_bar")
            ) {
                ScreenTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { onSelectTab(tab) },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            selectedTextColor = Color(0xFF38BDF8),
                            indicatorColor = Color(0xFF334155),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                ScreenTab.DASHBOARD -> DashboardScreen(
                    onNavigateToApps = { onSelectTab(ScreenTab.APPS) },
                    onNavigateToFavorites = { onSelectTab(ScreenTab.APPS) },
                    onNavigateToNotes = { onSelectTab(ScreenTab.NOTES) },
                    onNavigateToCalculator = { onSelectTab(ScreenTab.CALCULATOR) },
                    onNavigateToTimer = { onSelectTab(ScreenTab.TIMER) },
                    onNavigateToSettings = { onSelectTab(ScreenTab.SETTINGS) }
                )
                ScreenTab.APPS -> AppsManagerScreen(
                    onBack = { onSelectTab(ScreenTab.DASHBOARD) }
                )
                ScreenTab.NOTES -> NotesScreen(
                    onBack = { onSelectTab(ScreenTab.DASHBOARD) }
                )
                ScreenTab.CALCULATOR -> CalculatorScreen(
                    onBack = { onSelectTab(ScreenTab.DASHBOARD) }
                )
                ScreenTab.TIMER -> TimerScreen(
                    onBack = { onSelectTab(ScreenTab.DASHBOARD) }
                )
                ScreenTab.SETTINGS -> SettingsScreen(
                    onBack = { onSelectTab(ScreenTab.DASHBOARD) }
                )
            }
        }
    }
}
