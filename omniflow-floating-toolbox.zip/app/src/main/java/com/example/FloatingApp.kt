package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.AppDatabase
import com.example.data.PreferencesManager

class FloatingApp : Application() {

    override fun onCreate() {
        super.onCreate()
        AppDatabase.getInstance(this)
        PreferencesManager.getInstance(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                "floating_window_service_channel",
                "Floating Window Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating window pro bubble and toolbox running above other apps"
                setShowBadge(false)
            }

            val timerChannel = NotificationChannel(
                "timer_alerts_channel",
                "Timer & Stopwatch Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts and sound when countdown timer finishes"
                enableVibration(true)
            }

            notificationManager.createNotificationChannels(listOf(serviceChannel, timerChannel))
        }
    }
}
