package com.example

import com.example.util.CalculatorEngine
import com.example.util.TimerStopwatchEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FloatingWindowProUnitTest {

    @Test
    fun testCalculatorBasicOperations() {
        val add = CalculatorEngine.evaluate("12+34")
        assertTrue(add is CalculatorEngine.CalcResult.Success)
        assertEquals("46", (add as CalculatorEngine.CalcResult.Success).formatted)

        val sub = CalculatorEngine.evaluate("100-35")
        assertTrue(sub is CalculatorEngine.CalcResult.Success)
        assertEquals("65", (sub as CalculatorEngine.CalcResult.Success).formatted)

        val mul = CalculatorEngine.evaluate("8×9")
        assertTrue(mul is CalculatorEngine.CalcResult.Success)
        assertEquals("72", (mul as CalculatorEngine.CalcResult.Success).formatted)

        val div = CalculatorEngine.evaluate("81÷9")
        assertTrue(div is CalculatorEngine.CalcResult.Success)
        assertEquals("9", (div as CalculatorEngine.CalcResult.Success).formatted)
    }

    @Test
    fun testCalculatorDecimalsAndPercentage() {
        val dec = CalculatorEngine.evaluate("2.5+7.75")
        assertTrue(dec is CalculatorEngine.CalcResult.Success)
        assertEquals("10.25", (dec as CalculatorEngine.CalcResult.Success).formatted)

        val pct = CalculatorEngine.evaluate("200×15%")
        assertTrue(pct is CalculatorEngine.CalcResult.Success)
        assertEquals("30", (pct as CalculatorEngine.CalcResult.Success).formatted)
    }

    @Test
    fun testCalculatorParentheses() {
        val expr = CalculatorEngine.evaluate("(10+5)×2")
        assertTrue(expr is CalculatorEngine.CalcResult.Success)
        assertEquals("30", (expr as CalculatorEngine.CalcResult.Success).formatted)
    }

    @Test
    fun testCalculatorDivisionByZero() {
        val divZero = CalculatorEngine.evaluate("42÷0")
        assertTrue(divZero is CalculatorEngine.CalcResult.Error)
        assertEquals("Cannot divide by 0", (divZero as CalculatorEngine.CalcResult.Error).message)
    }

    @Test
    fun testTimerAndStopwatchFormatting() {
        val stopwatchStr = TimerStopwatchEngine.formatStopwatch(65430L)
        assertEquals("01:05.43", stopwatchStr)

        val timerStr = TimerStopwatchEngine.formatTimer(125000L)
        assertEquals("02:05", timerStr)
    }
}
